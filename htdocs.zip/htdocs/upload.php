<?php
session_start();

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "epics";
$conn = mysqli_connect($servername, $username, $password, $dbname);
// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}
else
{
  if(isset($_POST["insert"]))
  {
    $file=addslashes(file_get_contents($_FILES["image"]["tmp_name"]));
    $query="INSERT INTO photos(image) VALUES('$file')";



    if(mysqli_query($conn, $query))
    {
      echo '<script>alert("Image inserted")</script>';
    }
  }
}
?>
