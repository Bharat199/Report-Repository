<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "epics";
$conn = mysqli_connect($servername, $username, $password, $dbname);
// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}
else{
echo "hello";
$sql1="SELECT * FROM details";
$result = mysqli_query($conn,$sql1);

}

 ?>
